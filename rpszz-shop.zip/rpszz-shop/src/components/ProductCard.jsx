import styles from './ProductCard.module.css'

const STATUS_LABEL = {
  available: 'พร้อมขาย',
  reserved: 'จองแล้ว',
  sold: 'ขายแล้ว',
}

export default function ProductCard({ product }) {
  const { name, price, description, image_url, status, category } = product

  return (
    <div className={`${styles.card} ${styles[status]}`}>
      <div className={styles.imageWrap}>
        {image_url ? (
          <img src={image_url} alt={name} className={styles.image} />
        ) : (
          <div className={styles.noImage}>
            <span>ไม่มีรูป</span>
          </div>
        )}
        <span className={`badge badge-${status} ${styles.statusBadge}`}>
          {STATUS_LABEL[status]}
        </span>
        {category && (
          <span className={styles.category}>{category}</span>
        )}
      </div>

      <div className={styles.body}>
        <h3 className={styles.name}>{name}</h3>
        {description && (
          <p className={styles.desc}>{description}</p>
        )}
        <div className={styles.footer}>
          <span className={styles.price}>
            ฿{Number(price).toLocaleString()}
          </span>
          {status === 'available' && (
            <a
              href="https://line.me/ti/p/~YOUR_LINE_ID"
              target="_blank"
              rel="noreferrer"
              className={styles.buyBtn}
            >
              แชทสั่งซื้อ
            </a>
          )}
        </div>
      </div>
    </div>
  )
}

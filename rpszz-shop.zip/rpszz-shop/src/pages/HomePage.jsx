import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase.js'
import ProductCard from '../components/ProductCard.jsx'
import styles from './HomePage.module.css'

const FILTERS = ['ทั้งหมด', 'available', 'reserved', 'sold']
const FILTER_LABELS = {
  'ทั้งหมด': 'ทั้งหมด',
  available: 'พร้อมขาย',
  reserved: 'จองแล้ว',
  sold: 'ขายแล้ว',
}

export default function HomePage() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('ทั้งหมด')
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetchProducts()

    // Realtime subscription
    const channel = supabase
      .channel('products-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, fetchProducts)
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [])

  async function fetchProducts() {
    const { data } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false })
    setProducts(data || [])
    setLoading(false)
  }

  const filtered = products.filter(p => {
    const matchStatus = filter === 'ทั้งหมด' || p.status === filter
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase())
    return matchStatus && matchSearch
  })

  const counts = {
    available: products.filter(p => p.status === 'available').length,
    reserved:  products.filter(p => p.status === 'reserved').length,
    sold:      products.filter(p => p.status === 'sold').length,
  }

  return (
    <main>
      {/* Hero */}
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.tagline}>— มือสองคุณภาพ คัดมาแล้ว</p>
            <h1 className={styles.heroTitle}>
              RPSZZ<br />
              <span className={styles.heroShop}>.SHOP</span>
            </h1>
            <p className={styles.heroSub}>
              ของมือสองของ Rapeepong ทุกชิ้นผ่านการคัดสรร<br />
              สั่งซื้อผ่านแชทเท่านั้น
            </p>
            <div className={styles.heroActions}>
              <a
                href="https://line.me/ti/p/~YOUR_LINE_ID"
                target="_blank"
                rel="noreferrer"
                className={styles.primaryBtn}
              >
                แชทสั่งซื้อ LINE
              </a>
              <a href="#products" className={styles.secondaryBtn}>
                ดูสินค้า ↓
              </a>
            </div>
          </div>
        </div>
        <div className={styles.heroAccent} />
      </section>

      {/* Stats bar */}
      <section className={styles.statsBar}>
        <div className="container">
          <div className={styles.stats}>
            <div className={styles.stat}>
              <span className={styles.statNum}>{counts.available}</span>
              <span className={styles.statLabel}>พร้อมขาย</span>
            </div>
            <div className={styles.statDivider} />
            <div className={styles.stat}>
              <span className={`${styles.statNum} ${styles.yellow}`}>{counts.reserved}</span>
              <span className={styles.statLabel}>จองแล้ว</span>
            </div>
            <div className={styles.statDivider} />
            <div className={styles.stat}>
              <span className={`${styles.statNum} ${styles.red}`}>{counts.sold}</span>
              <span className={styles.statLabel}>ขายแล้ว</span>
            </div>
          </div>
        </div>
      </section>

      {/* Products section */}
      <section className={styles.productsSection} id="products">
        <div className="container">
          {/* Controls */}
          <div className={styles.controls}>
            <div className={styles.filterGroup}>
              {FILTERS.map(f => (
                <button
                  key={f}
                  className={`${styles.filterBtn} ${filter === f ? styles.activeFilter : ''}`}
                  onClick={() => setFilter(f)}
                >
                  {FILTER_LABELS[f]}
                </button>
              ))}
            </div>
            <input
              type="text"
              placeholder="ค้นหาสินค้า..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className={styles.searchInput}
            />
          </div>

          {/* Grid */}
          {loading ? (
            <div className={styles.loading}>
              <div className={styles.spinner} />
              <span>กำลังโหลด...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className={styles.empty}>
              <p>ไม่มีสินค้าในขณะนี้</p>
            </div>
          ) : (
            <div className={styles.grid}>
              {filtered.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Reviews placeholder */}
      <section className={styles.reviewSection}>
        <div className="container">
          <h2 className={styles.sectionTitle}>รีวิวจากลูกค้า</h2>
          <div className={styles.reviewGrid}>
            {[
              { name: 'ธนา P.', text: 'ของดีมากครับ ตรงปก จัดส่งไวมาก', rating: 5 },
              { name: 'พิม S.',  text: 'ชอบมากเลยค่ะ คุ้มราคาสุดๆ', rating: 5 },
              { name: 'กิตติ W.', text: 'สภาพดีกว่าที่คิดไว้เยอะเลยครับ', rating: 5 },
            ].map((r, i) => (
              <div key={i} className={styles.reviewCard}>
                <div className={styles.stars}>{'★'.repeat(r.rating)}</div>
                <p className={styles.reviewText}>"{r.text}"</p>
                <span className={styles.reviewer}>— {r.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <div className="container">
          <p className={styles.footerLogo}>
            <span style={{ color: 'var(--red)' }}>R</span>PSZZ.shop
          </p>
          <p className={styles.footerSub}>สินค้าทุกชิ้นสั่งซื้อผ่านแชทเท่านั้น — ไม่มีระบบตะกร้าสินค้า</p>
          <p className={styles.footerCopy}>© 2025 Rapeepong · Rpszz.shop</p>
        </div>
      </footer>
    </main>
  )
}

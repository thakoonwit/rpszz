import { useState } from 'react'
import { supabase } from '../lib/supabase.js'
import styles from './TrackPage.module.css'

const STATUS_MAP = {
  available: { label: 'ยังไม่ได้จอง',  color: '#4ade80', icon: '○' },
  reserved:  { label: 'จองสำเร็จแล้ว', color: '#fbbf24', icon: '◑' },
  sold:      { label: 'ดำเนินการแล้ว', color: '#f87171', icon: '●' },
}

export default function TrackPage() {
  const [phone, setPhone] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [searched, setSearched] = useState(false)

  async function handleSearch(e) {
    e.preventDefault()
    if (!phone.trim()) return
    setLoading(true)
    setSearched(true)

    const clean = phone.replace(/\D/g, '')
    const { data } = await supabase
      .from('orders')
      .select('*, products(*)')
      .eq('customer_phone', clean)
      .order('created_at', { ascending: false })

    setResults(data || [])
    setLoading(false)
  }

  return (
    <main className={styles.page}>
      <div className="container">
        <div className={styles.header}>
          <h1 className={styles.title}>เช็คสถานะ<br /><span>สินค้า</span></h1>
          <p className={styles.sub}>ใส่เบอร์โทรที่ใช้แชทสั่งซื้อ</p>
        </div>

        <form onSubmit={handleSearch} className={styles.form}>
          <div className={styles.inputGroup}>
            <input
              type="tel"
              placeholder="เบอร์โทร เช่น 0812345678"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className={styles.input}
              maxLength={10}
            />
            <button type="submit" className={styles.searchBtn} disabled={loading}>
              {loading ? 'กำลังค้นหา...' : 'ค้นหา'}
            </button>
          </div>
        </form>

        {searched && !loading && (
          <div className={styles.results}>
            {results.length === 0 ? (
              <div className={styles.empty}>
                <p>ไม่พบรายการสั่งซื้อจากเบอร์นี้</p>
                <span>หากมีปัญหา กรุณาติดต่อผ่านแชท</span>
              </div>
            ) : (
              <>
                <p className={styles.resultMeta}>
                  พบ {results.length} รายการจากเบอร์ {phone}
                </p>
                <div className={styles.orderList}>
                  {results.map(order => {
                    const s = STATUS_MAP[order.status] || STATUS_MAP.reserved
                    return (
                      <div key={order.id} className={styles.orderCard}>
                        <div className={styles.orderTop}>
                          {order.products?.image_url && (
                            <img
                              src={order.products.image_url}
                              alt={order.products?.name}
                              className={styles.thumb}
                            />
                          )}
                          <div className={styles.orderInfo}>
                            <h3 className={styles.productName}>
                              {order.products?.name || 'สินค้า'}
                            </h3>
                            <p className={styles.orderDate}>
                              {new Date(order.created_at).toLocaleDateString('th-TH', {
                                year: 'numeric', month: 'long', day: 'numeric'
                              })}
                            </p>
                            {order.note && (
                              <p className={styles.note}>หมายเหตุ: {order.note}</p>
                            )}
                          </div>
                          <div className={styles.statusWrap}>
                            <span className={styles.statusIcon} style={{ color: s.color }}>
                              {s.icon}
                            </span>
                            <span className={styles.statusLabel} style={{ color: s.color }}>
                              {s.label}
                            </span>
                          </div>
                        </div>
                        <div className={styles.orderBottom}>
                          <span className={styles.priceTag}>
                            ฿{Number(order.products?.price || 0).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </>
            )}

            <div className={styles.chatNote}>
              <p>มีคำถาม? แชทหาเราได้เลย</p>
              <a
                href="https://line.me/ti/p/~YOUR_LINE_ID"
                target="_blank"
                rel="noreferrer"
                className={styles.lineBtn}
              >
                ติดต่อ LINE
              </a>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}

import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase.js'
import toast from 'react-hot-toast'
import styles from './AdminPage.module.css'

const EMPTY_FORM = {
  name: '', description: '', price: '', category: '',
  image_url: '', status: 'available'
}

export default function AdminPage() {
  const [password, setPassword] = useState('')
  const [authed, setAuthed] = useState(false)
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [form, setForm] = useState(EMPTY_FORM)
  const [editing, setEditing] = useState(null)
  const [tab, setTab] = useState('products')
  const [loading, setLoading] = useState(false)

  const ADMIN_PASS = import.meta.env.VITE_ADMIN_PASSWORD || 'rpszz2025'

  function handleLogin(e) {
    e.preventDefault()
    if (password === ADMIN_PASS) {
      setAuthed(true)
      fetchAll()
    } else {
      toast.error('รหัสผ่านไม่ถูกต้อง')
    }
  }

  async function fetchAll() {
    const [{ data: p }, { data: o }] = await Promise.all([
      supabase.from('products').select('*').order('created_at', { ascending: false }),
      supabase.from('orders').select('*, products(name)').order('created_at', { ascending: false }),
    ])
    setProducts(p || [])
    setOrders(o || [])
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    const payload = { ...form, price: Number(form.price) }

    if (editing) {
      const { error } = await supabase.from('products').update(payload).eq('id', editing)
      if (error) toast.error('อัพเดทไม่สำเร็จ')
      else { toast.success('อัพเดทสำเร็จ'); setEditing(null) }
    } else {
      const { error } = await supabase.from('products').insert(payload)
      if (error) toast.error('เพิ่มสินค้าไม่สำเร็จ')
      else toast.success('เพิ่มสินค้าสำเร็จ')
    }

    setForm(EMPTY_FORM)
    fetchAll()
    setLoading(false)
  }

  async function handleDelete(id) {
    if (!confirm('ลบสินค้านี้?')) return
    await supabase.from('products').delete().eq('id', id)
    toast.success('ลบแล้ว')
    fetchAll()
  }

  async function updateStatus(id, status) {
    await supabase.from('products').update({ status }).eq('id', id)
    toast.success(`เปลี่ยนเป็น: ${status}`)
    fetchAll()
  }

  async function updateOrderStatus(id, status) {
    await supabase.from('orders').update({ status }).eq('id', id)
    fetchAll()
  }

  function startEdit(p) {
    setEditing(p.id)
    setForm({ name: p.name, description: p.description || '',
      price: p.price, category: p.category || '',
      image_url: p.image_url || '', status: p.status })
    setTab('form')
    window.scrollTo(0, 0)
  }

  if (!authed) {
    return (
      <div className={styles.loginPage}>
        <form onSubmit={handleLogin} className={styles.loginCard}>
          <h1 className={styles.loginTitle}>ADMIN</h1>
          <p className={styles.loginSub}>Rpszz.shop Backend</p>
          <input
            type="password"
            placeholder="รหัสผ่าน"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className={styles.loginInput}
          />
          <button type="submit" className={styles.loginBtn}>เข้าสู่ระบบ</button>
        </form>
      </div>
    )
  }

  return (
    <div className={styles.page}>
      <div className="container">
        <div className={styles.topBar}>
          <h1 className={styles.pageTitle}>ADMIN PANEL</h1>
          <button onClick={() => setAuthed(false)} className={styles.logoutBtn}>ออกจากระบบ</button>
        </div>

        {/* Tabs */}
        <div className={styles.tabs}>
          {['form', 'products', 'orders'].map(t => (
            <button
              key={t}
              className={`${styles.tab} ${tab === t ? styles.activeTab : ''}`}
              onClick={() => setTab(t)}
            >
              {{ form: editing ? '✎ แก้ไขสินค้า' : '＋ เพิ่มสินค้า', products: `สินค้า (${products.length})`, orders: `คำสั่งซื้อ (${orders.length})` }[t]}
            </button>
          ))}
        </div>

        {/* Product Form */}
        {tab === 'form' && (
          <form onSubmit={handleSubmit} className={styles.form}>
            <h2 className={styles.formTitle}>{editing ? 'แก้ไขสินค้า' : 'เพิ่มสินค้าใหม่'}</h2>
            <div className={styles.formGrid}>
              <label className={styles.field}>
                <span>ชื่อสินค้า *</span>
                <input required value={form.name} onChange={e => setForm({...form, name: e.target.value})}
                  placeholder="เช่น Nike Air Max 90 Size 42" className={styles.input} />
              </label>
              <label className={styles.field}>
                <span>ราคา (บาท) *</span>
                <input required type="number" value={form.price}
                  onChange={e => setForm({...form, price: e.target.value})}
                  placeholder="1500" className={styles.input} />
              </label>
              <label className={styles.field}>
                <span>หมวดหมู่</span>
                <input value={form.category}
                  onChange={e => setForm({...form, category: e.target.value})}
                  placeholder="เช่น รองเท้า, เสื้อผ้า, กระเป๋า" className={styles.input} />
              </label>
              <label className={styles.field}>
                <span>สถานะ</span>
                <select value={form.status}
                  onChange={e => setForm({...form, status: e.target.value})}
                  className={styles.input}>
                  <option value="available">พร้อมขาย</option>
                  <option value="reserved">จองแล้ว</option>
                  <option value="sold">ขายแล้ว</option>
                </select>
              </label>
              <label className={`${styles.field} ${styles.fullWidth}`}>
                <span>URL รูปภาพ</span>
                <input value={form.image_url}
                  onChange={e => setForm({...form, image_url: e.target.value})}
                  placeholder="https://..." className={styles.input} />
              </label>
              <label className={`${styles.field} ${styles.fullWidth}`}>
                <span>รายละเอียด</span>
                <textarea value={form.description}
                  onChange={e => setForm({...form, description: e.target.value})}
                  placeholder="สภาพ, ขนาด, รายละเอียดอื่นๆ"
                  rows={3} className={styles.input} />
              </label>
            </div>
            <div className={styles.formActions}>
              <button type="submit" className={styles.submitBtn} disabled={loading}>
                {loading ? 'กำลังบันทึก...' : editing ? 'บันทึกการแก้ไข' : 'เพิ่มสินค้า'}
              </button>
              {editing && (
                <button type="button" className={styles.cancelBtn}
                  onClick={() => { setEditing(null); setForm(EMPTY_FORM); setTab('products') }}>
                  ยกเลิก
                </button>
              )}
            </div>
          </form>
        )}

        {/* Products Table */}
        {tab === 'products' && (
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>รูป</th>
                  <th>ชื่อ</th>
                  <th>ราคา</th>
                  <th>หมวด</th>
                  <th>สถานะ</th>
                  <th>จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {products.map(p => (
                  <tr key={p.id}>
                    <td>
                      {p.image_url
                        ? <img src={p.image_url} alt={p.name} className={styles.tableThumb} />
                        : <div className={styles.noThumb} />
                      }
                    </td>
                    <td className={styles.tdName}>{p.name}</td>
                    <td>฿{Number(p.price).toLocaleString()}</td>
                    <td className={styles.tdMuted}>{p.category || '—'}</td>
                    <td>
                      <select
                        value={p.status}
                        onChange={e => updateStatus(p.id, e.target.value)}
                        className={`${styles.statusSelect} ${styles[`status_${p.status}`]}`}
                      >
                        <option value="available">พร้อมขาย</option>
                        <option value="reserved">จองแล้ว</option>
                        <option value="sold">ขายแล้ว</option>
                      </select>
                    </td>
                    <td>
                      <div className={styles.actions}>
                        <button onClick={() => startEdit(p)} className={styles.editBtn}>แก้ไข</button>
                        <button onClick={() => handleDelete(p.id)} className={styles.deleteBtn}>ลบ</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Orders */}
        {tab === 'orders' && (
          <div className={styles.tableWrap}>
            <p className={styles.orderNote}>
              * รายการ Order ต้องเพิ่มผ่านหลังบ้านหลังแชทกับลูกค้า
            </p>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>สินค้า</th>
                  <th>เบอร์โทร</th>
                  <th>ชื่อ</th>
                  <th>วันที่</th>
                  <th>สถานะ</th>
                  <th>หมายเหตุ</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.id}>
                    <td>{o.products?.name || '—'}</td>
                    <td className={styles.tdPhone}>{o.customer_phone}</td>
                    <td>{o.customer_name || '—'}</td>
                    <td className={styles.tdMuted}>
                      {new Date(o.created_at).toLocaleDateString('th-TH')}
                    </td>
                    <td>
                      <select
                        value={o.status}
                        onChange={e => updateOrderStatus(o.id, e.target.value)}
                        className={`${styles.statusSelect} ${styles[`status_${o.status}`]}`}
                      >
                        <option value="reserved">จองแล้ว</option>
                        <option value="sold">ส่งแล้ว</option>
                      </select>
                    </td>
                    <td className={styles.tdMuted}>{o.note || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import App from './App.jsx'
import './styles/globals.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="bottom-center"
        toastOptions={{
          style: {
            background: '#1a2235',
            color: '#f8f9fc',
            border: '1px solid rgba(248,249,252,0.1)',
            fontFamily: "'Sarabun', sans-serif",
          },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>
)

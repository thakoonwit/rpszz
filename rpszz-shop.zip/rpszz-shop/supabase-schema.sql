-- ===== RPSZZ.SHOP — Supabase Schema =====
-- รันใน Supabase SQL Editor

-- 1. Products table
CREATE TABLE products (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  price       NUMERIC NOT NULL DEFAULT 0,
  category    TEXT,
  image_url   TEXT,
  status      TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'sold')),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Orders table (สำหรับ admin บันทึกหลังแชท)
CREATE TABLE orders (
  id               UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id       UUID REFERENCES products(id) ON DELETE SET NULL,
  customer_phone   TEXT NOT NULL,
  customer_name    TEXT,
  status           TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved', 'sold')),
  note             TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- 4. RLS Policies
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders   ENABLE ROW LEVEL SECURITY;

-- Public can READ products
CREATE POLICY "Public read products"
  ON products FOR SELECT USING (true);

-- Public can READ orders (for phone lookup)
CREATE POLICY "Public read orders"
  ON orders FOR SELECT USING (true);

-- All writes require service_role (admin only via anon key restricted)
-- For simplicity: allow all inserts/updates (protect via VITE_ADMIN_PASSWORD in frontend)
-- In production: use Supabase Auth for proper admin auth

CREATE POLICY "Admin insert products"
  ON products FOR INSERT WITH CHECK (true);

CREATE POLICY "Admin update products"
  ON products FOR UPDATE USING (true);

CREATE POLICY "Admin delete products"
  ON products FOR DELETE USING (true);

CREATE POLICY "Admin insert orders"
  ON orders FOR INSERT WITH CHECK (true);

CREATE POLICY "Admin update orders"
  ON orders FOR UPDATE USING (true);

-- 5. Enable Realtime for products
ALTER TABLE products REPLICA IDENTITY FULL;

-- ===== Sample Data =====
INSERT INTO products (name, description, price, category, status) VALUES
  ('Nike Air Max 90 Size 42', 'สภาพ 9/10 ใส่ไปแค่ 2 ครั้ง กล่องครบ', 2500, 'รองเท้า', 'available'),
  ('Levi''s 501 W32 L30', 'สภาพดีมาก สีไม่ซีด', 800, 'เสื้อผ้า', 'available'),
  ('กระเป๋า Anello สีดำ', 'ของแท้ สภาพ 8/10', 650, 'กระเป๋า', 'reserved');

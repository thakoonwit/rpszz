# RPSZZ.shop — Setup Guide

เว็บโชว์เคสมือสอง พร้อม Track Status และ Admin Panel

---

## Stack
- **Frontend**: React + Vite + CSS Modules
- **Database**: Supabase (PostgreSQL + Realtime)
- **Deploy**: Vercel
- **Source**: GitHub

---

## 1. ตั้ง Supabase

1. ไปที่ [supabase.com](https://supabase.com) → New Project
2. ตั้งชื่อ project เป็น `rpszz-shop`
3. เข้า **SQL Editor** → New Query → วาง code จาก `supabase-schema.sql` → Run
4. ไปที่ **Project Settings > API** → copy:
   - `Project URL`
   - `anon public` key

---

## 2. ตั้งค่า Local

```bash
# Clone repo
git clone https://github.com/YOUR_USERNAME/rpszz-shop.git
cd rpszz-shop

# ติดตั้ง dependencies
npm install

# สร้างไฟล์ env
cp .env.example .env.local
```

แก้ไข `.env.local`:
```
VITE_SUPABASE_URL=https://xxxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5c...
VITE_ADMIN_PASSWORD=รหัสผ่านที่ต้องการ
```

```bash
# รัน dev server
npm run dev
```

---

## 3. Push ขึ้น GitHub

```bash
git init
git add .
git commit -m "init rpszz shop"
git remote add origin https://github.com/YOUR_USERNAME/rpszz-shop.git
git push -u origin main
```

---

## 4. Deploy บน Vercel

1. ไปที่ [vercel.com](https://vercel.com) → New Project → Import จาก GitHub
2. เลือก repo `rpszz-shop`
3. ไปที่ **Environment Variables** → เพิ่ม:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_ADMIN_PASSWORD`
4. กด **Deploy**

---

## 5. ตั้ง Custom Domain

1. Vercel → Project → Settings → Domains
2. เพิ่ม `rpszz.shop`
3. ตั้ง DNS ที่ Domain Registrar:
   - A Record: `76.76.21.21`
   - CNAME: `www` → `cname.vercel-dns.com`

---

## หน้าเว็บ

| URL | คำอธิบาย |
|-----|---------|
| `/` | หน้าหลัก — โชว์สินค้าทั้งหมด |
| `/track` | เช็คสถานะโดยใส่เบอร์โทร |
| `/admin` | หลังบ้าน — จัดการสินค้า + orders |

---

## Workflow การขาย

```
ลูกค้าเห็นสินค้าในเว็บ
       ↓
แชท LINE มาจอง
       ↓
Admin เข้า /admin → เปลี่ยน Status เป็น "จองแล้ว"
       ↓
Admin บันทึก Order ใส่เบอร์ลูกค้า
       ↓
ลูกค้าเช็ค /track ด้วยเบอร์โทร
       ↓
ส่งของ → Admin เปลี่ยน Status เป็น "ขายแล้ว"
```

---

## การแก้ไข LINE ID

ค้นหา `YOUR_LINE_ID` ในไฟล์:
- `src/components/Navbar.jsx`
- `src/pages/HomePage.jsx`
- `src/pages/TrackPage.jsx`

แล้วเปลี่ยนเป็น LINE ID จริง เช่น `~rapeepong_shop`

---

## Realtime Updates

สินค้าในหน้าหลักจะอัพเดทอัตโนมัติทันทีที่ Admin เปลี่ยน Status  
ไม่ต้อง refresh หน้า — ใช้ Supabase Realtime
